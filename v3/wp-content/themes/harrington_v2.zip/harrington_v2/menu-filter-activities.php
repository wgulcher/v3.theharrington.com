<select id="network" class="standard-dropdown sub-filter-dropdown multiselect span12 filter-class-view event" multiple="multiple">
    <option value="01,02,03,04,05,06,07,08,09,10,11,12"><a><i class="icon-linkedin icon-border"></i>All Dates</a></option>
    <option value="06"><a><i class="icon-linkedin icon-border"></i>June</a></option>
    <option value="07"><a><i class="icon-linkedin icon-border"></i>July</a></option>
    <option value="08"><a><i class="icon-cloud icon-border"></i>August</a></option>
    <option value="09"><a><i class="icon-cloud icon-border"></i>September</a></option>
    <option value="10"><a><i class="icon-cloud icon-border"></i>October</a></option>
    <option value="11"><a><i class="icon-cloud icon-border"></i>November</a></option>
    <option value="12"><a><i class="icon-cloud icon-border"></i>December</a></option>
</select>

<select id="network" class="standard-dropdown sub-filter-dropdown multiselect span12 filter-class-view restaurant" multiple="multiple">
    <option value="cafe,french,gastropub,indian,italian,oriental,poshnosh,steakhouse"><a><i class="icon-linkedin icon-border"></i>All Resturants</a></option>
    <option value="cafe"><a><i class="icon-linkedin icon-border"></i>Cafe</a></option>
    <option value="french"><a><i class="icon-cloud icon-border"></i>French</a></option>
    <option value="gastropub"><a><i class="icon-cloud icon-border"></i>Gastro Pub</a></option>
    <option value="indian"><a><i class="icon-cloud icon-border"></i>Indian</a></option>
    <option value="italian"><a><i class="icon-cloud icon-border"></i>Italian</a></option>
    <option value="oriental"><a><i class="icon-cloud icon-border"></i>Oriental</a></option>
    <option value="poshnosh"><a><i class="icon-cloud icon-border"></i>Posh Nosh</a></option>
    <option value="steakhouse"><a><i class="icon-cloud icon-border"></i>SteakHouse</a></option>
</select>

