<select id="network" class="standard-dropdown filter-dropdown multiselect" multiple="multiple">
    <option value="March"><a><i class="icon-linkedin icon-border"></i>March</a></option>
    <option value="February"><a><i class="icon-linkedin icon-border"></i>February</a></option>
    <option value="January"><a><i class="icon-cloud icon-border"></i>January</a></option>
    <option value="December"><a><i class="icon-cloud icon-border"></i>December</a></option>
</select>
